package com.animationlib.mixin.client;

import com.animationlib.api.Vec3f;
import com.animationlib.impl.AnimationPlayerImpl;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerModel.class)
abstract class PlayerModelMixin {
    @Shadow
    @Final
    public ModelPart head;
    @Shadow
    @Final
    public ModelPart body;
    @Shadow
    @Final
    public ModelPart leftArm;
    @Shadow
    @Final
    public ModelPart rightArm;
    @Shadow
    @Final
    public ModelPart leftLeg;
    @Shadow
    @Final
    public ModelPart rightLeg;

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V", at = @At("TAIL"))
    private void animationlib$applyAnimation(AvatarRenderState state, CallbackInfo ci) {
        AnimationPlayerImpl.sample(state.id).ifPresent(sample -> {
            animationlib$applyBone(head, sample, "head");
            animationlib$applyBone(body, sample, "body");
            animationlib$applyBone(leftArm, sample, "arm_left");
            animationlib$applyBone(rightArm, sample, "arm_right");
            animationlib$applyBone(leftLeg, sample, "leg_left");
            animationlib$applyBone(rightLeg, sample, "leg_right");
        });
    }

    private static void animationlib$applyBone(ModelPart part, AnimationPlayerImpl.Sample sample, String bone) {
        Vec3f rotation = sample.rotation(bone);
        if (rotation != null) {
            part.offsetRotation(new Vector3f(
                    (float) Math.toRadians(rotation.x()),
                    (float) Math.toRadians(rotation.y()),
                    (float) Math.toRadians(rotation.z())
            ));
        }

        Vec3f position = sample.position(bone);
        if (position != null) {
            part.offsetPos(new Vector3f(position.x(), position.y(), position.z()));
        }
    }
}
