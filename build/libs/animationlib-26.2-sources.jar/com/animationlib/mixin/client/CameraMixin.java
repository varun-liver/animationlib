package com.animationlib.mixin.client;

import com.animationlib.api.Vec3f;
import com.animationlib.impl.AnimationPlayerImpl;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
abstract class CameraMixin {
    @Shadow
    public abstract Entity entity();

    @Shadow
    public abstract float xRot();

    @Shadow
    public abstract float yRot();

    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    @Shadow
    protected abstract void move(float x, float y, float z);

    @Inject(method = "update", at = @At("TAIL"))
    private void animationlib$applyCameraAnimation(DeltaTracker deltaTracker, CallbackInfo ci) {
        Entity entity = this.entity();
        if (entity == null) {
            return;
        }

        AnimationPlayerImpl.sample(entity.getId()).ifPresent(sample -> {
            Vec3f rotation = sample.rotation("camera");
            if (rotation != null) {
                this.setRotation(this.yRot() + rotation.y(), this.xRot() + rotation.x());
            }

            Vec3f position = sample.position("camera");
            if (position != null) {
                this.move(position.x(), position.y(), position.z());
            }
        });
    }
}
