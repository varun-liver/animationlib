package com.animationlib;

import net.fabricmc.api.ModInitializer;

public class Animationlib implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
