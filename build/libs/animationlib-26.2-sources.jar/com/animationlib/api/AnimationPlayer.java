package com.animationlib.api;

import com.animationlib.impl.AnimationPlayerImpl;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

/**
 * Plays a loaded animation on an entity. While playing, its {@code head}, {@code body},
 * {@code arm_left}, {@code arm_right}, {@code leg_left}, {@code leg_right} bones are applied to
 * the entity's rendered player model each frame, and its {@code camera} bone is applied to that
 * entity's camera if it's the client's own player.
 */
public final class AnimationPlayer {
    private AnimationPlayer() {
    }

    public static void play(Entity entity, Identifier animationId) {
        AnimationPlayerImpl.play(entity.getId(), animationId);
    }

    public static void stop(Entity entity) {
        AnimationPlayerImpl.stop(entity.getId());
    }

    public static boolean isPlaying(Entity entity) {
        return AnimationPlayerImpl.isPlaying(entity.getId());
    }
}
