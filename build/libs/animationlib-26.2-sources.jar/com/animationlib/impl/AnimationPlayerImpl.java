package com.animationlib.impl;

import com.animationlib.api.AnimationData;
import com.animationlib.api.AnimationRegistry;
import com.animationlib.api.BoneAnimation;
import com.animationlib.api.Vec3f;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/** Tracks which animation each entity is currently playing, keyed by entity id. */
public final class AnimationPlayerImpl {
    private static final Logger LOGGER = LoggerFactory.getLogger("animationlib");
    private static final Map<Integer, Playing> PLAYING = new ConcurrentHashMap<>();

    private AnimationPlayerImpl() {
    }

    public static void play(int entityId, Identifier animationId) {
        AnimationRegistry.get(animationId).ifPresentOrElse(
                data -> PLAYING.put(entityId, new Playing(data, System.currentTimeMillis())),
                () -> LOGGER.warn("animationlib: unknown animation {}", animationId)
        );
    }

    public static void stop(int entityId) {
        PLAYING.remove(entityId);
    }

    public static boolean isPlaying(int entityId) {
        return PLAYING.containsKey(entityId);
    }

    public static Optional<Sample> sample(int entityId) {
        Playing playing = PLAYING.get(entityId);
        if (playing == null) {
            return Optional.empty();
        }

        double time = (System.currentTimeMillis() - playing.startMillis) / 1000.0;
        double length = playing.data.length();
        if (length > 0 && time >= length) {
            if (playing.data.loop()) {
                time %= length;
            } else {
                PLAYING.remove(entityId);
                return Optional.empty();
            }
        }

        return Optional.of(new Sample(playing.data, time));
    }

    private record Playing(AnimationData data, long startMillis) {
    }

    public record Sample(AnimationData data, double time) {
        public Vec3f rotation(String bone) {
            return channel(bone, BoneAnimation::rotation);
        }

        public Vec3f position(String bone) {
            return channel(bone, BoneAnimation::position);
        }

        private Vec3f channel(String bone, Function<BoneAnimation, com.animationlib.api.BoneChannel> selector) {
            BoneAnimation boneAnimation = data.bones().get(bone);
            return boneAnimation == null ? null : AnimationSampler.sample(selector.apply(boneAnimation), time);
        }
    }
}
