package com.animationlib.mixin.client;

import com.animationlib.api.Vec3f;
import com.animationlib.client.ItemBoneApplier;
import com.animationlib.impl.AnimationPlayerImpl;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The local player's own head is never rendered in first person, and the visible hand/arm is
 * drawn here rather than through {@link net.minecraft.client.model.player.PlayerModel} (see
 * {@link PlayerModelMixin}) - so arm animations need a separate hook to be visible in first
 * person. Only rotation is applied (not position): this renderer works in a different coordinate
 * space/scale than the player model's bones, so a position offset tuned for the model would be
 * wildly wrong here.
 */
@Mixin(FirstPersonHandsAndItemsRenderer.class)
abstract class ItemInHandRendererMixin {
    @Inject(method = "renderPlayerArm", at = @At("HEAD"))
    private void animationlib$pushBareArm(PoseStack poseStack, SubmitNodeCollector collector, int light,
            float partialTicks, float equipProgress, HumanoidArm arm, PlayerRenderState state, CallbackInfo ci) {
        animationlib$pushArmPose(poseStack, arm);
    }

    @Inject(method = "renderPlayerArm", at = @At("RETURN"))
    private void animationlib$popBareArm(PoseStack poseStack, SubmitNodeCollector collector, int light,
            float partialTicks, float equipProgress, HumanoidArm arm, PlayerRenderState state, CallbackInfo ci) {
        poseStack.popPose();
    }

    @Inject(method = "submitArmWithItem", at = @At("HEAD"))
    private void animationlib$pushItemArm(PlayerRenderState state, FirstPersonHandsAndItemsRenderState handsState, float partialTicks, float pitch,
            InteractionHand hand, float swingProgress, ItemStack stack, float equipProgress,
            PoseStack poseStack, SubmitNodeCollector collector, int light, CallbackInfo ci) {
        HumanoidArm mainArm = state.avatarRenderState.mainArm;
        HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? mainArm : mainArm.getOpposite();
        animationlib$pushArmPose(poseStack, arm);
    }

    @Inject(method = "submitArmWithItem", at = @At("RETURN"))
    private void animationlib$popItemArm(PlayerRenderState state, FirstPersonHandsAndItemsRenderState handsState, float partialTicks, float pitch,
            InteractionHand hand, float swingProgress, ItemStack stack, float equipProgress,
            PoseStack poseStack, SubmitNodeCollector collector, int light, CallbackInfo ci) {
        poseStack.popPose();
    }

    // Fires right before each place the held item itself is drawn, so the item can be animated
    // independently of the arm (the arm hook above already moves the item along with the arm).
    @Inject(method = "submitArmWithItem", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/item/ItemStackRenderState;submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;III)V"))
    private void animationlib$animateHeldItem(PlayerRenderState state, FirstPersonHandsAndItemsRenderState handsState, float partialTicks, float pitch,
            InteractionHand hand, float swingProgress, ItemStack stack, float equipProgress,
            PoseStack poseStack, SubmitNodeCollector collector, int light, CallbackInfo ci) {
        var player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }

        HumanoidArm mainArm = state.avatarRenderState.mainArm;
        HumanoidArm arm = hand == InteractionHand.MAIN_HAND ? mainArm : mainArm.getOpposite();
        ItemBoneApplier.apply(poseStack, player.getId(), arm);
    }

    // Always pairs with a popPose() in the matching @At("RETURN") injector above, even when there's
    // no local player or no animation playing, so the stack stays balanced on every code path.
    private static void animationlib$pushArmPose(PoseStack poseStack, HumanoidArm arm) {
        poseStack.pushPose();

        var player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }

        AnimationPlayerImpl.sample(player.getId()).ifPresent(sample -> {
            String bone = arm == HumanoidArm.LEFT ? "arm_left" : "arm_right";
            Vec3f rotation = sample.rotation(bone);
            if (rotation != null) {
                poseStack.mulPose(new Matrix4f().rotationXYZ(
                        (float) Math.toRadians(rotation.x()),
                        (float) Math.toRadians(rotation.y()),
                        (float) Math.toRadians(rotation.z())));
            }
        });
    }
}
